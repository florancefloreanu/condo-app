//IIFE -- Immediately Invoked Function Expression
"use strict";

(function () {

    function confirmDelete() {
        $("a.delete").on("click", function (event) {
            if (!confirm("Are you sure?")) {
                event.preventDefault();
                location.href = '/contact-list';
            }
        });
    }
    function Start(): void {
        console.log("App Started");
        confirmDelete();
    }

    window.addEventListener("load", Start);

})();


