Fisrt install the dependencies using following command. 

npm install 

start node server using following commands.

nodemon

Navigate to :http://localhost:3000/




