export const LocalURI = "mongodb://localhost/condo";
export const HostName = "RemoteHost";
export const Secret = "someSecret";
export const RemoteURI = "mongodb+srv://admin:Epy425ctity0ouoH@cluster0.ldexq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
export const isDev = false; //make it false once you put in remoteURI