"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isDev = exports.RemoteURI = exports.Secret = exports.HostName = exports.LocalURI = void 0;
exports.LocalURI = "mongodb://localhost/condo";
exports.HostName = "RemoteHost";
exports.Secret = "someSecret";
exports.RemoteURI = "mongodb+srv://admin:Epy425ctity0ouoH@cluster0.ldexq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
exports.isDev = false;
//# sourceMappingURL=db.js.map