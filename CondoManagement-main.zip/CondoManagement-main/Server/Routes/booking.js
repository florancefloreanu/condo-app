"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const router = express_1.default.Router();
exports.default = router;
const bookingcontroller_1 = require("../Controllers/bookingcontroller");
const Util_1 = require("../Util");
router.get('/list', Util_1.AuthGuard, bookingcontroller_1.DisplayBookingList);
router.get('/:name', Util_1.AuthGuard, bookingcontroller_1.DisplayBooking);
router.post('/:name', Util_1.AuthGuard, bookingcontroller_1.ProcessBooking);
//# sourceMappingURL=booking.js.map